# -*- coding:utf-8 -*-

from magicsquare import *