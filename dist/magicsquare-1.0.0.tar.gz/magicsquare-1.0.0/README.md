# Magic_Square
This is a program which can generate solutions for any size of [Magic Square](https://en.wikipedia.org/wiki/Magic_square) problem. This program applies three different algorithms, and it also contains a validation function for generated solutions.
This is an unique composite solution in Python.

